import sys
from .wiktrola import cli
def run():
    cli()