# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['wiktrola']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=3.1.2,<4.0.0',
 'gTTS>=2.2.4,<3.0.0',
 'rich-click>=1.3.0,<2.0.0',
 'wikipedia>=1.4.0,<2.0.0']

entry_points = \
{'console_scripts': ['pyKaraoke = wiktrola.script:run']}

setup_kwargs = {
    'name': 'wiktrola',
    'version': '0.1.0',
    'description': 'Transform any Wikipedia article into an MP3',
    'long_description': '# wiktrola\nTransform any Wikipedia page into an MP3 file!\n',
    'author': 'John Capobianco',
    'author_email': 'ptcapo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
